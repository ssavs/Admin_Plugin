<?php

echo "Activate or disable Admin Bar Frontend";